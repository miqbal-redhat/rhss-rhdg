#!/bin/sh
# Sample shell script to read and act on properties

# source the properties:
. properties/rhsso-cluster-script.properties

BINARIES_DIR=$binarydir
WORK_DIR=$workingdir
PATCH_DIR=$patchdir
DELIVERABLE_DIR=$outdir
DB_DRIVERS_DIR=$dbdriversdir
BINARY_FILE_NAME=$binaryname
PATCH_FILE_NAME=$patchname
DB_DRIVES_FILE=$dbdriversfile
IS_PATCH_AVAILALE=$isPatchAvailable
TARGET_WORK_DIR=$ssodir
SSO_HOME=$WORK_DIR/$TARGET_WORK_DIR
ADMIN_USER=$adminuser
ADMIN_PASSWORD=$adminpassword

echo "************************* START CONFIGURING RH SSO BINARIES *********************************"

cp $BINARIES_DIR/$BINARY_FILE_NAME $WORK_DIR/

echo "  >>>> EXTRACTING BINARIES <<<< "

unzip $WORK_DIR/$BINARY_FILE_NAME -d $WORK_DIR/


echo "  >>>> ADDING DEFAULT ADMIN USER <<<< "

./$SSO_HOME/bin/add-user.sh -u $ADMIN_USER -p $ADMIN_PASSWORD -g 'admin'


echo "  >>>> Copy drivers as module <<<< "

cp -r modules/com $SSO_HOME/modules 

echo "  >>>> Replaces server configurations with custom configurations  <<<< "

rm -rf $SSO_HOME/standalone/configuration/standalone-ha.xml

cp configurations/standalone-ha.xml $SSO_HOME/standalone/configuration/



echo "  >>>> Clean and package the custom binaries  <<<< "

rm -rf $WORK_DIR/$BINARY_FILE_NAME

cd $WORK_DIR

zip -r ../deliverable/refinitive-sso.zip $TARGET_WORK_DIR

rm -rf $TARGET_WORK_DIR


echo "************************* COMPLETED CONFIGURING RH SSO BINARIES *****************************"






